#include "pch.h"
#include <cassert>
#include <cstdlib>
#include <ctime>
#include <memory>
#include <stdexcept>
#include <vector>

// Uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

// Global test environment setup and teardown
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    void SetUp() override
    {
        // Initialize the random-number generator.
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    void TearDown() override {}
};

// Test fixture used to provide a fresh vector for every unit test.
class CollectionTest : public ::testing::Test
{
protected:
    // Smart pointer that stores the vector used by each test.
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    {
        // Create a new empty collection before each test.
        collection = std::make_unique<std::vector<int>>();
    }

    void TearDown() override
    {
        // Clear the collection and release the pointer after each test.
        collection->clear();
        collection.reset();
    }

    // Add a requested number of random values between 0 and 99.
    void add_entries(int count)
    {
        assert(count > 0);

        for (int i = 0; i < count; ++i)
        {
            collection->push_back(rand() % 100);
        }
    }
};

// Test that the smart pointer was successfully created.
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    ASSERT_TRUE(collection);
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a newly created collection is empty.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    ASSERT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

/*
 * This intentionally failing test must remain commented out.
 * Uncomment it only when demonstrating a failed unit test.

TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}
*/

// Test that one value can be added to an empty collection.
TEST_F(CollectionTest, CanAddSingleValueToEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0U);

    add_entries(1);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1U);
}

// Test that five values can be added to an empty collection.
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());

    add_entries(5);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5U);
}

// Test that max_size is greater than or equal to size
// for collections containing 0, 1, 5, and 10 entries.
TEST_F(CollectionTest, MaxSizeIsGreaterThanOrEqualToCurrentSize)
{
    ASSERT_EQ(collection->size(), 0U);
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(1);
    EXPECT_EQ(collection->size(), 1U);
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(4);
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_GE(collection->max_size(), collection->size());

    add_entries(5);
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_GE(collection->max_size(), collection->size());
}

// Test that capacity is greater than or equal to size
// for collections containing 0, 1, 5, and 10 entries.
TEST_F(CollectionTest, CapacityIsGreaterThanOrEqualToCurrentSize)
{
    ASSERT_EQ(collection->size(), 0U);
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(1);
    EXPECT_EQ(collection->size(), 1U);
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(4);
    EXPECT_EQ(collection->size(), 5U);
    EXPECT_GE(collection->capacity(), collection->size());

    add_entries(5);
    EXPECT_EQ(collection->size(), 10U);
    EXPECT_GE(collection->capacity(), collection->size());
}

// Test that resize increases the collection size.
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5U);

    collection->resize(10);

    EXPECT_EQ(collection->size(), 10U);
    EXPECT_FALSE(collection->empty());
}

// Test that resize decreases the collection size.
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10U);

    collection->resize(5);

    EXPECT_EQ(collection->size(), 5U);
    EXPECT_FALSE(collection->empty());
}

// Test that resize can decrease the collection size to zero.
TEST_F(CollectionTest, ResizeCanDecreaseCollectionToZero)
{
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->resize(0);

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Test that clear removes every element from the collection.
TEST_F(CollectionTest, ClearErasesEntireCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5U);

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Test that erase(begin, end) removes every element.
TEST_F(CollectionTest, EraseRangeRemovesEntireCollection)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5U);

    collection->erase(collection->begin(), collection->end());

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0U);
}

// Test that reserve increases capacity without changing size.
TEST_F(CollectionTest, ReserveIncreasesCapacityWithoutChangingSize)
{
    add_entries(5);

    ASSERT_EQ(collection->size(), 5U);

    const std::size_t originalSize = collection->size();
    const std::size_t requestedCapacity = collection->capacity() + 20U;

    collection->reserve(requestedCapacity);

    EXPECT_EQ(collection->size(), originalSize);
    EXPECT_GE(collection->capacity(), requestedCapacity);
}

// Negative test: accessing an invalid index must throw out_of_range.
TEST_F(CollectionTest, AtThrowsOutOfRangeForInvalidIndex)
{
    ASSERT_TRUE(collection->empty());

    EXPECT_THROW(
        static_cast<void>(collection->at(1)),
        std::out_of_range);
}

// Custom positive test: push_back stores the specified value.
TEST_F(CollectionTest, PushBackStoresExpectedValue)
{
    const int expectedValue = 42;

    ASSERT_TRUE(collection->empty());

    collection->push_back(expectedValue);

    ASSERT_EQ(collection->size(), 1U);
    EXPECT_EQ(collection->back(), expectedValue);
}

// Custom negative test: index equal to size is outside the valid range.
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexEqualsSize)
{
    add_entries(5);

    ASSERT_EQ(collection->size(), 5U);

    EXPECT_THROW(
        static_cast<void>(collection->at(collection->size())),
        std::out_of_range);
}

::testing::Environment* const globalEnvironment =
::testing::AddGlobalTestEnvironment(new Environment);