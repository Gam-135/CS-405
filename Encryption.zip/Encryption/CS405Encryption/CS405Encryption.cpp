// Encryption.cpp : This file contains the 'main' function.
// Program execution begins and ends there.

#include <cassert>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>

/// <summary>
/// Encrypts or decrypts a source string using the provided key.
/// XOR encryption uses the same operation for encryption and decryption.
/// </summary>
/// <param name="source">Input string to process</param>
/// <param name="key">Key used for encryption or decryption</param>
/// <returns>Transformed string</returns>
std::string encrypt_decrypt(
    const std::string& source,
    const std::string& key)
{
    // Store the lengths so they do not need to be recalculated
    // during every loop iteration.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // Confirm that the source and encryption key contain data.
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // Process each character in the source string.
    for (size_t i = 0; i < source_length; ++i)
    {
        // Use modulo to restart at the beginning of the key
        // whenever the end of the key is reached.
        output[i] = source[i] ^ key[i % key_length];
    }

    // The encrypted or decrypted output should have the same
    // number of characters as the source.
    assert(output.length() == source_length);

    return output;
}

/// <summary>
/// Reads the complete contents of a text file into a string.
/// </summary>
/// <param name="filename">Name of the file to read</param>
/// <returns>Complete contents of the file</returns>
std::string read_file(const std::string& filename)
{
    // Open the file in binary mode so that all characters,
    // including line breaks, are preserved.
    std::ifstream input_file(filename, std::ios::binary);

    if (!input_file.is_open())
    {
        throw std::runtime_error(
            "Unable to open input file: " + filename);
    }

    // Read the entire file into a string stream.
    std::ostringstream file_buffer;
    file_buffer << input_file.rdbuf();

    input_file.close();

    return file_buffer.str();
}

/// <summary>
/// Extracts the student's name from the first line of the input data.
/// </summary>
/// <param name="string_data">Input file contents</param>
/// <returns>Student name</returns>
std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // Find the first newline.
    const size_t pos = string_data.find('\n');

    if (pos != std::string::npos)
    {
        // Copy the first line as the student name.
        student_name = string_data.substr(0, pos);

        // Remove a carriage-return character when reading a
        // Windows-formatted text file.
        if (!student_name.empty() && student_name.back() == '\r')
        {
            student_name.pop_back();
        }
    }
    else
    {
        // Use all available text if the file contains only one line.
        student_name = string_data;
    }

    return student_name;
}

/// <summary>
/// Saves the student's name, date, encryption key, and data to a file.
/// </summary>
/// <param name="filename">Name of the output file</param>
/// <param name="student_name">Student's name</param>
/// <param name="key">Encryption key used</param>
/// <param name="data">Encrypted or decrypted data</param>
void save_data_file(
    const std::string& filename,
    const std::string& student_name,
    const std::string& key,
    const std::string& data)
{
    // Binary mode preserves every encrypted byte exactly.
    std::ofstream output_file(
        filename,
        std::ios::binary | std::ios::trunc);

    if (!output_file.is_open())
    {
        throw std::runtime_error(
            "Unable to create output file: " + filename);
    }

    // Obtain the current local date.
    const std::time_t current_time = std::time(nullptr);
    std::tm local_time{};

#ifdef _WIN32
    localtime_s(&local_time, &current_time);
#else
    localtime_r(&current_time, &local_time);
#endif

    // Required output format:
    // Line 1: Student name
    // Line 2: Date in yyyy-mm-dd format
    // Line 3: Encryption key
    // Line 4 and later: Data
    output_file << student_name << '\n';
    output_file << std::put_time(&local_time, "%Y-%m-%d") << '\n';
    output_file << key << '\n';
    output_file.write(
        data.data(),
        static_cast<std::streamsize>(data.size()));

    output_file.close();

    if (!output_file)
    {
        throw std::runtime_error(
            "An error occurred while saving: " + filename);
    }
}

int main()
{
    std::cout << "Encryption Decryption Test!" << std::endl;

    // Input file format:
    // Line 1: Student name
    // Line 2: Lorem Ipsum Generator website used
    // Lines 3+: Three generated paragraphs

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";

    // Keep this spelling because it is the filename defined
    // in the provided starter code.
    const std::string decrypted_file_name =
        "decrytpteddatafile.txt";

    const std::string key = "password";

    try
    {
        // Load the original file.
        const std::string source_string = read_file(file_name);

        // Get the student's name from the first line.
        const std::string student_name =
            get_student_name(source_string);

        // Encrypt the original data.
        const std::string encrypted_string =
            encrypt_decrypt(source_string, key);

        save_data_file(
            encrypted_file_name,
            student_name,
            key,
            encrypted_string);

        // Applying XOR with the same key restores the original data.
        const std::string decrypted_string =
            encrypt_decrypt(encrypted_string, key);

        save_data_file(
            decrypted_file_name,
            student_name,
            key,
            decrypted_string);

        // Verify that encryption and decryption restored the data.
        assert(decrypted_string == source_string);

        std::cout << "Read File: " << file_name
            << " - Encrypted To: " << encrypted_file_name
            << " - Decrypted To: " << decrypted_file_name
            << std::endl;

        std::cout
            << "Encryption and decryption completed successfully."
            << std::endl;

        std::cout
            << "The decrypted data matches the original input."
            << std::endl;
    }
    catch (const std::exception& error)
    {
        std::cerr << "Program error: "
            << error.what()
            << std::endl;

        return 1;
    }

    return 0;
}