// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
#include <cstring>

int main()
{
  std::cout << "Buffer Overflow Example" << std::endl;

  const std::string account_number = "CharlieBrown42";
  char user_input[20];

  // Read input into a safer std::string first so the fixed-size character
  // buffer is not overwritten by input that is too large.
  std::string temporary_input;

  std::cout << "Enter a value: ";
  std::cin >> temporary_input;

  // The user_input buffer has room for 20 characters total, including the
  // null terminator. This means the maximum safe input length is 19 characters.
  if (temporary_input.length() >= sizeof(user_input))
  {
    std::cout << "Buffer overflow condition detected." << std::endl;
    std::cout << "Input was too large for the user_input buffer and was rejected." << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
    return 1;
  }

  // Copy the validated input into the fixed-size character buffer only after
  // confirming that it fits safely.
  std::strcpy(user_input, temporary_input.c_str());

  std::cout << "You entered: " << user_input << std::endl;
  std::cout << "Account Number = " << account_number << std::endl;

  return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu